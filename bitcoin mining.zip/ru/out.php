<?
session_start();
  unset($_SESSION['loginses']);
  header('location:../index.php');


?>